namespace stackList{
#include "LinkedList.h"
}

template<typename DType>
class Stack{
private:
    stackList:: LinkedList <DType>myStackList;
public:
    Stack(){}
    //Complete the Methods
    void push(DType data){}
    void pop(){}
    DType top(){}
    void display(){}
};
