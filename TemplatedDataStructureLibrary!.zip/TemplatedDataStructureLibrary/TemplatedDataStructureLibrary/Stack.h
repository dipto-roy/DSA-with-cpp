namespace stackList
{
#include "LinkedList.h"
}

template<typename DType>
class Stack
{
private:
    stackList:: LinkedList <DType>myStackList;
public:
    Stack() {}
    //Complete the Methods
    void push(DType data)
    {
        template<typename DType>
        void Stack<DType>::push(DType data)
        {
            myStackList.insertAtFirst(data);
        }
    }
    void pop()
    {
        template<typename DType>
        void Stack<DType>::pop()
        {
            myStackList.deleteAtFirst();
        }
    }
    DType top()
    {
        template<typename DType>
        DType Stack<DType>::top()
        {
            return myStackList.getFirstElement();
        }
    }
    void display()
    {
        template<typename DType>
        void Stack<DType>::display()
        {
            myStackList.display();
        }
    }
};
